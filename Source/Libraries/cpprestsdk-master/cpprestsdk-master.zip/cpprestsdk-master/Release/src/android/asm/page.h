#pragma once

// This file is to fix a break introduced by Android 5 in Boost 1.55.

// As noted in http://code.google.com/p/android/issues/detail?id=39983, asm/page.h was removed.
